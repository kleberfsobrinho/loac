// Davi Gomes Passos Sousa
// executar o código C na placa FPGA (com argumentos)

int lupi(register int x, register int y);